Name: Patrick Rice - ONID: ricep
"This is my assignment-1 submission!"
